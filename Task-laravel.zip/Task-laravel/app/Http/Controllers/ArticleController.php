<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Pagination\LengthAwarePaginator;

class ArticleController extends Controller
{
    public function index(Request $request)
{
    $apiKey = config('services.newsapi.key');
    $keyword = $request->input('search', 'technology'); // Default keyword or use user input
    $url = "https://newsapi.org/v2/everything?q=tesla&from=2024-04-27&sortBy=publishedAt&apiKey=$apiKey";

    $response = Http::get($url);

    if ($response->failed()) {
        return view('News.alrticle', ['error' => 'Failed to fetch articles']);
    }

    $articles = $response->json()['articles'];

    // Filter articles by title, source, publishedAt, and author
    if ($request->filled('search')) {
        $searchTerm = strtolower($request->input('search'));
        $articles = array_filter($articles, function ($article) use ($searchTerm) {
            return strpos(strtolower($article['title']), $searchTerm) !== false ||
                strpos(strtolower($article['source']['name']), $searchTerm) !== false ||
                strpos(strtolower($article['publishedAt']), $searchTerm) !== false ||
                strpos(strtolower($article['author']), $searchTerm) !== false;
        });
    }

    // Pagination
    $perPage = 10;
    $page = $request->input('page', 1);
    $pagination = new LengthAwarePaginator(
        array_slice($articles, ($page - 1) * $perPage, $perPage),
        count($articles),
        $perPage,
        $page,
        ['path' => $request->url(), 'query' => $request->query()]
    );

    return view('News.alrticle', ['articles' => $pagination]);
}

    // public function index(Request $request)
    // {
    //     $apiKey = config('services.newsapi.key');
    //     $url = 'https://newsapi.org/v2/everything?q=keyword&apiKey=' . $apiKey;
    //     //$url = 'https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=' . $apiKey;
    //     $response = Http::get($url);
        
    //     if ($response->failed()) {
    //         return view('News.alrticle', ['error' => 'Failed to fetch articles']);
    //     }
        
    //     $articles = $response->json()['articles'];

    //     // Pagination
    //     $perPage = 10;
    //     $page = $request->input('page', 1);
    //     $pagination = new LengthAwarePaginator(
    //         array_slice($articles, ($page - 1) * $perPage, $perPage),
    //         count($articles),
    //         $perPage,
    //         $page,
    //         ['path' => $request->url(), 'query' => $request->query()]
    //     );

    //     return view('News.alrticle', ['articles' => $pagination]);
    // }
}
