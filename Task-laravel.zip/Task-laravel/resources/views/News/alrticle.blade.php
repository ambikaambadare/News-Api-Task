<style>
    .pagination {
    display: flex;
    justify-content: center;
    list-style: none;
    padding: 0;
}

.pagination li {
    margin: 0 5px;
}

.pagination li a {
    padding: 5px 10px;
    border: 1px solid #ccc;
    text-decoration: none;
    color: #333;
    transition: background-color 0.3s;
}

.pagination li a:hover {
    background-color: #f0f0f0;
}

.pagination li.active a {
    background-color: #007bff;
    color: #fff;
    border-color: #007bff;
}

.pagination li.disabled span {
    color: #ccc;
}

.search-form {
    display: flex;
    margin-bottom: 20px;
}

.search-input {
    flex: 1;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px 0 0 4px;
}

.search-button {
    padding: 8px 16px;
    background-color: #007bff;
    color: white;
    border: 1px solid #007bff;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
}

.search-button:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}



</style>

@extends('layouts.app')

@section('content')
    <div style="padding:10px;">
        <h1 class="text-2xl font-bold mb-4">Articles</h1>
        
        <form action="{{ route('articles.index') }}" method="GET" class="mb-4">
            <input type="text" name="search" class="search-input" placeholder="Search...">
            <button type="submit" class="search-button">Search</button>
        </form>

        @if(isset($error))
            <div class="text-red-500">{{ $error }}</div>
        @else
            <table class="min-w-full table-auto border-collapse border border-gray-400">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="border border-gray-300 px-4 py-2">Title</th>
                        <th class="border border-gray-300 px-4 py-2">Source</th>
                        <th class="border border-gray-300 px-4 py-2">Published At</th>
                        <th class="border border-gray-300 px-4 py-2">Author</th>
                        <th class="border border-gray-300 px-4 py-2">Description</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($articles as $article)
                        <tr>
                            <td class="border border-gray-300 px-4 py-2">{{ $article['title'] }}</td>
                            <td class="border border-gray-300 px-4 py-2">{{ $article['source']['name'] }}</td>
                            <td class="border border-gray-300 px-4 py-2">{{ date('d/m/Y', strtotime($article['publishedAt'])) }}</td>
                            <td class="border border-gray-300 px-4 py-2">{{ $article['author'] }}</td>
                            <td class="border border-gray-300 px-4 py-2">{{ $article['description'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            
            <div class="mt-4">
                {{ $articles->links() }}
            </div>
        @endif
    </div>
@endsection
