<!DOCTYPE html>
<html>
<head>
    <title>News App</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mx-auto py-8">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH E:\Task-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>